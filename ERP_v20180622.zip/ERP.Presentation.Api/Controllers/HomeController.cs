﻿using ERP.Infra.Data.EFContexts;
using ERP.Presentation.Api.Models;
using ERP.RH.Domain.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ERP.Presentation.Api.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View(new FuncionarioModel().ListaFuncionarios());
        }

        public ActionResult FichaCadastral(int id)
        {
            ViewBag.Message = "Your contact page.";
            FuncionarioModel model = new FuncionarioModel(id);
            return View(model);
        }

    }
}
