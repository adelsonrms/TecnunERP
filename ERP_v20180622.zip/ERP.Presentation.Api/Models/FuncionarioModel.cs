﻿using ERP.Infra.Data.EFContexts;
using Infra.Data.Repositories;
using ERP.RH.Domain.Entidades;
using System.Collections.Generic;

namespace ERP.Presentation.Api.Models
{
    public class FuncionarioModel
    {
        Funcionario _model;              //Modelo
        FuncionarioRepositorio UserRep;  //Repositório

        public Funcionario Model { get {return _model;} }

        private void iniciaRepositorio(EFDbContext _db)
        {
            UserRep = new FuncionarioRepositorio(_db);
        }

        public FuncionarioModel()
        {
            iniciaRepositorio(new EFDbContext());
        }

        public FuncionarioModel(int idFuncionario)
        {
            iniciaRepositorio(new EFDbContext());
            _model = UserRep.ObterPorId(idFuncionario);
        }

        public IEnumerable<Funcionario> ListaFuncionarios()
        {
            IEnumerable<Funcionario> lista;
            try
            {
                lista = UserRep.ObterTodos();
            }
            catch (System.Exception)
            {
                lista = null;
            }
            return lista;
        }


    }
}