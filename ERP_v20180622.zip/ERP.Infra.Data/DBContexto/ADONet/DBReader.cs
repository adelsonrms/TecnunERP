﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ERP.Infra.Data
{
    class DBReader
    {
        /// <summary>
        /// Executa um comando no banco de dados com uma conexão ativa e retorna um DataReader com os dados.
        /// </summary>
        /// <param name="sqlCommand">Comando SQL</param>
        /// <returns></returns>
        public IDataReader GetReader(string sqlCommand)
        {
            using (var cnn = DBConnection.Connection)
            {
                IDataReader red;
                try
                {
                    red = DBContext.GetData(sqlCommand, cnn);
                }
                //Erro especifico na abertura da conexão
                catch (Infra.Data.Exceptions.DALExceptionConnectionOpen)
                {
                }
                //Erro especifico na conexçao
                catch (Infra.Data.Exceptions.DALExceptionConnectionError)
                {
                }
                //Erro qualquer
                catch (Exception ex)
                {
                    throw new Infra.Data.Exceptions.DALExceptionExecuteReader(ex.Message);
                }
                finally
                {
                    red=null;
                }
                //Retorno do reader
                return red;
            }
        }
    }
}
