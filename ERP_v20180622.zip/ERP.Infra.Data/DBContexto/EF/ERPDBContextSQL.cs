﻿using Base.Entidades;
using ERP.RH.Domain.Entidades;
using ERP.RH.Domain.Generic;
using ERP.RH.Domain.Regional;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace ERP.Infra.Data.EFContexts
{
    public class EFDbContext : DbContext
    {
        public EFDbContext(string connectionString):base(connectionString)
        {
            inicializaConexto();
        }

        public EFDbContext() : base("name=CS_ERP_DbSQL") {
            inicializaConexto();
        }

        private void inicializaConexto()
        {
            //Atribui o inicializador ao contexto
            //Na classe 'EFContextInitializer' estão ações que são executadas ao inicializar o contexto
            Database.SetInitializer<EFDbContext>(new EFContextInitializer());
        }

        public void CarregarDadosIniciais()
        {
            EFContextInitializer inicitializer = new EFContextInitializer();
            inicitializer.GerarDadosIniciais(this);
        }
        //Datasets
        
        public DbSet<Funcionario> Funcionarios { get; set; }
        public DbSet<Contrato> Contratos { get; set; }
        public DbSet<Cidade> Cidades { get; set; }
        public DbSet<Estado> Estados { get; set; }
        public DbSet<Endereco> Endereços { get; set; }
        public DbSet<Telefone> Telefones { get; set; }


        //Inicializa/Criação do DB, caso nao exista
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

            //Desliga algumas opções
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Conventions.Remove<PluralizingEntitySetNameConvention>();

            //Classes que devem ser ignoradas do mapeamento para não gerar tabelas.
            //Não são entidades
            modelBuilder.Ignore<Entidade>();
            modelBuilder.Ignore<EntidadeBase>();
            modelBuilder.Ignore<Pessoa>();
            modelBuilder.Ignore<Property>();
            
            

            
            //modelBuilder.Entity<Pessoa>().ToTable("Pessoa");
            //modelBuilder.Entity<Pessoa>().HasKey(t => t.Id);

            modelBuilder.Configurations.Add(new Mapping.FuncionarioMapping());

            /*---------------------------------------------------------------------------------------------------------------------------
             * Configurações gerais para todos os campos (propriedades) e tabelas do banco de dados
             ---------------------------------------------------------------------------------------------------------------------------*/

            //Configura o tipo e tamanho padrão para criação dos campos. Assim o migration não irá mais criar tipo nvarchar(max)
            //modelBuilder.Properties<string>().Configure(p => p.HasColumnType("varchar"));
            //modelBuilder.Properties<string>().Configure(p => p.HasMaxLength(100));

            //Essa instrução verifica se alguma proproiedade da classe possui um campo no padrão "NomeClasseId". 
            //Caso identifique, configura-a como chave primeira (PK) na tabela
            //modelBuilder.Properties()
            //    .Where(p => p.Name == p.ReflectedType.Name + "Id")
            //    .Configure(p => p.IsKey());
        }
    }
}
