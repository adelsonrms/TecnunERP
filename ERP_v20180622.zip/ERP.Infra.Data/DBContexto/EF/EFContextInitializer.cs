﻿using ERP.RH.Domain.Cadastro;
using ERP.RH.Domain.Entidades;
using ERP.RH.Domain.Regional;
using ERP.Shared;
using ERP.Shared.Extensions;
using ERP.Shared.ValueObjects;
using System;
using System.Data.Entity;
namespace ERP.Infra.Data.EFContexts
{
    /// <summary>
    /// Define um inicializador para a classe de contexto.
    /// Um inicializador especifica ações que serão executadas quando o contexto é criado para o banco de dados.
    /// </summary>
    public class EFContextInitializer:DropCreateDatabaseAlways<EFDbContext>
    {
        /// <summary>
        /// Esse metodo será executado sempre que o banco for recriado.
        /// </summary>
        /// <param name="context">Representa a instancia do DbContext</param>
        protected override void Seed(EFDbContext context)
        {
            GerarDadosIniciais(context);
        }

        public void GerarDadosIniciais(EFDbContext context)
        {
             try
            {

            Funcionario usuario;
            //Cria um usuário

            //------------------------------------------------------------------------
            //Informações Basicas
            //------------------------------------------------------------------------
            usuario = new Funcionario 
            {
                Nome= "Adelson Silva",
                DataNascimento=new System.DateTime(1982,8,14),
                SexoID = Enuns.eSexo.Masculino.Value(),
                EmailPessoal = "adelson@tecnun.com.br",
                EmailProfissional = "adelsons@gmail.com"
            };

            //-------------------------------------------------------------------------
            //Adiciona informações adicionais
            //-------------------------------------------------------------------------
            
            //Endereço
            Endereco endereco = new RH.Domain.Regional.Endereco()
            {
                Logradouro = "Rua José Adão",
                Numero = "58",
                Bairro = "Vila dos Palmares",
                CEP = "05273-110",
                Cidade = new Cidade 
                { 
                    Nome = "São Paulo", 
                    Estado = new Estado 
                    {  
                        Nome="São Paulo", 
                        UF="SP"
                    } 
                }
            };

            //Telefone
            Telefone telefone = new Telefone 
            { 
                Celular = "11 96798-0117", Comercial = "2178-4205", Residencial = "39128020" 
            };

            Contrato contrato = new Contrato
            {
                TipoDeContrato = Enuns.eTipoContrato.Trabalho
                //DataAdimissao = new DateTime(2013, 12,01)
            };

            context.Endereços.Add(endereco);
            context.SaveChanges();

            context.Telefones.Add(telefone);
            context.SaveChanges();

            context.Contratos.Add(contrato);
            context.SaveChanges();

            usuario.Endereco = endereco;
            usuario.Telefone = telefone;
            usuario.Contrato = contrato;

            //-------------------------------------------------------------------------
            //Adiciona no contexto
            //-------------------------------------------------------------------------
            context.Funcionarios.Add(usuario);


            usuario = new Funcionario
            {
                Nome = "Fernando Ortega",
                DataNascimento = new System.DateTime(1978, 11, 21),
                SexoID = Enuns.eSexo.Masculino.Value(),
                EmailPessoal = "ortega@tecnun.com.br",
                EmailProfissional = "fernando.ortega@uol.com.br"
            };
            context.Funcionarios.Add(usuario);

            usuario = new Funcionario
            {
                Nome = "Milene Bispo",
                DataNascimento = new System.DateTime(1985, 01, 13),
                SexoID = Enuns.eSexo.Masculino.Value(),
                EmailPessoal = "milene@tecnun.com.br",
                EmailProfissional = "mbispo@gmail.com"
            };
            context.Funcionarios.Add(usuario); 

            context.SaveChanges();

            


            }
            catch (Exception)
            {

                throw;
            }


            

            

        }
    }
}
