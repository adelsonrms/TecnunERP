﻿#region "Recursos do Sistema"
using ERP.Shared;
using ERP.Shared.ValueObjects;
using System;
#endregion

namespace ERP.RH.Domain.Entidades
{
    /// <summary>
    /// Representa a aabstração de uma pessoa genericamente.
    /// Uma pessoa pode assumir diferentes entidades no sistema.
    /// Por ex : Usuário, Funcionario, Fornecedor, entre outras representações.
    /// Cada pessoa tem que ter pelo menos uma nome e uma indicação do tipo (Fisica ou Juridica)
    /// </summary>
    public abstract class Pessoa//: Generic.Entidade
    {
        /// <summary>
        /// Inicializa uma nova pessoa. Padrão PF
        /// </summary>
        public Pessoa()
        {
            PessoaID = Guid.NewGuid().ToString().Substring(1, 6);
            //base.SetChildClass(this);
            TipoPessoa = Enuns.eTipoPessoa.PF;
        }

        public string PessoaID { get ; set;} 
        /// <summary>
        /// Representa o nome de identificação da entidade.
        /// </summary>
        public string Nome { get; set; }
        /// <summary>
        /// Identifica o tipo (PF ou PJ)
        /// </summary>
        public Enuns.eTipoPessoa TipoPessoa { get; set; }

    }
}
