﻿using Base.Entidades;
using System;
namespace ERP.RH.Domain.Generic
{
    public abstract class Entidade : EntidadeBase
    {
        public Entidade() { 
            base.SetChildClass(this);
            this.Id = Guid.NewGuid().ToString();
        }

        public string Id { get; set;}
        
    }}
