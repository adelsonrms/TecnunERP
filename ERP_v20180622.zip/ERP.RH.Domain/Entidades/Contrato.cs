﻿using ERP.Shared;

namespace ERP.RH.Domain.Entidades
{
   public  class Contrato//: Generic.Entidade
    {
       //public Contrato()
       //{
       //        ContratoID = System.Guid.NewGuid().ToString().Substring(1, 6);
       //}
       public int ContratoID { get; set; }
       public Enuns.eTipoContrato TipoDeContrato { get; set; }
    }
}
