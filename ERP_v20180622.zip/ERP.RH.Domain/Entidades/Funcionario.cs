﻿#region "Namepaces .Net"
using System.Collections.Generic; //A propriedade Contatos necessita dessa bliblioteca
#endregion
#region "Namepaces do Sistema"
using Base.Entidades;
using ERP.Shared;
using ERP.Shared.ValueObjects;  //Expõe os ValuesObjects (Nome, Email, etc..)
using ERP.Shared.Extensions;    //Expõe os metodos extendidos
using ERP.RH.Domain.Regional;   //Expoe os objetos de cadastro do funcionario
using ERP.RH.Domain.Generic;
using System;    //Expoe entidades genericas
#endregion

namespace ERP.RH.Domain.Entidades
{
    /// <summary>
    /// Representa um Funcionario da empresa.
    /// Um Funcionario herda de uma pessoa genericamente.
    /// Para um funcionário, no entanto, é necessário especificar algumas informações adicionais como por ex
    ///     Contatos, Dados Cadastrais
    /// </summary>
    public class Funcionario : Pessoa
    {
        public int FuncionarioID { get; set; }
        public Funcionario()
        {
            //FuncionarioID = Guid.NewGuid().ToString().Substring(1, 6);
            //base.SetChildClass(this);
        }
        public string EmailPessoal {get; set;}
        public string EmailProfissional { get; set; }
        public DateTime DataNascimento { get; set; }
        public int SexoID { get; set; }
        public int StatusID { get; set; }
        public int EstadoCivel { get; set; }

        public virtual Endereco Endereco { get; set; }
        public virtual Telefone Telefone { get; set; }
        public virtual Contrato Contrato { get; set; }

        public override string ToString()
        {
            return base.Nome;
        }
    }

}
