﻿using Base.Entidades;
namespace ERP.RH.Domain.Cadastro
{
   public class Contato //:EntidadeBase
    {
        public int ContatoID { get; set; }
        public int TipoContatoID { get; set; }
        public string ValorContato { get; set; }

        public override string ToString()
        {
            return this.ValorContato;
        }

    }
}
