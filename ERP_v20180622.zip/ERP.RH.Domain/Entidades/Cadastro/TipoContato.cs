﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ERP.RH.Domain.Cadastro
{
   public class TipoContato
    {
        public int TipoContatoID { get; set; }
        public string Nome { get; set; }
    }
}
