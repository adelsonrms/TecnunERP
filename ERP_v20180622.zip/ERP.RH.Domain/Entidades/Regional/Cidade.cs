﻿namespace ERP.RH.Domain.Regional
{
    public class Cidade
    {
        public int CidadeID { get; set; }
        public string Nome { get; set; }
        public virtual Estado Estado { get; set; }
        
        public Cidade()
        {
            Estado = new Estado();
        }
        public override string ToString() { return this.Nome + '-' + Estado.UF; }
    }
}
