﻿using ERP.RH.Domain.Entidades;
using ERP.RH.Domain.Regional;
namespace ERP.RH.Domain.Regional
{
    public class Endereco//Base.Entidades.EntidadeBase
    {
        public int EnderecoID { get; set; }
        public string Logradouro { get; set; }
        public string Numero { get; set; }
        public string CEP { get; set; }
        public string Bairro { get; set; }
        public virtual Cidade Cidade { get; set; }
        //public virtual Funcionario Funcionario { get; set; }

        public override string ToString()
        {
            return string.Concat(this.Logradouro, ", ", this.Numero, " CEP : ", CEP, " ", Cidade.Nome, "-", Cidade.Estado.UF) ;
        }
    }
}
